const Voting = artifacts.require("Voting");

module.exports = function (deployer) {
  const candidates = [
    web3.utils.asciiToHex("Abdullah"),
    web3.utils.asciiToHex("Ali"),
    web3.utils.asciiToHex("Burhan"),
    web3.utils.asciiToHex("Idrees"),
    web3.utils.asciiToHex("Taimoor"),
  ];
 
  deployer.deploy(Voting, candidates);
};


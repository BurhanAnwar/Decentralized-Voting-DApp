let web3, account, voting;

window.addEventListener('load', async () => {
  // 1. Initialize Web3
  if (window.ethereum) {
    web3 = new Web3(window.ethereum);
    await window.ethereum.request({ method: 'eth_requestAccounts' });
  } else {
    alert('Please install MetaMask to use this DApp');
    return;
  }

  // 2. Get the connected account
  const accounts = await web3.eth.getAccounts();
  account = accounts[0];
  document.getElementById('account').innerText = `Connected: ${account}`;

  // 3. Load contract ABI & address
  const res = await fetch('./Voting.json');
  const ContractJSON = await res.json();
  const networkId = await web3.eth.net.getId();
  const deployed = ContractJSON.networks[networkId];
  voting = new web3.eth.Contract(ContractJSON.abi, deployed.address);

  // 4. Render the candidate list
  await renderCandidates();
});

async function renderCandidates() {
  const candidatesDiv = document.getElementById('candidates');
  const status = document.getElementById('status');
  candidatesDiv.innerHTML = 'Loading candidates...';
  status.innerText = '';

  // 1. Get candidate list
  const bytes32Candidates = await voting.methods.getCandidateList().call();
  candidatesDiv.innerHTML = ''; // clear the loader

  // 2. Loop through each candidate
  for (const bytes32Name of bytes32Candidates) {
    const name = web3.utils.hexToAscii(bytes32Name).replace(/\u0000/g, ''); // remove padding

    const votes = await voting.methods.totalVotesFor(bytes32Name).call();

    const row = document.createElement('div');
    row.className = 'candidate';
    row.innerHTML = `
      <span>${name} — ${votes} votes</span>
      <button data-name="${bytes32Name}">Vote</button>
    `;

    row.querySelector('button').onclick = async (e) => {
      const candidate = e.target.getAttribute('data-name');
      status.innerText = 'Casting vote...';
      try {
        await voting.methods.voteForCandidate(candidate).send({ from: account });
        status.innerText = `You voted for ${name}!`;
        await renderCandidates();
      } catch (err) {
        console.error(err);
        status.innerText = 'Error: ' + err.message;
      }
    };

    candidatesDiv.appendChild(row);
  }
}


